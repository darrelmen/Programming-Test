import * as actionTypes from './actions';
import data from './data';


let reducer = (state, action) => {
  var list = [...data];

  //removing duplicates
  const uniques = list.reduce((acc, current) => {
    const x = acc.find(item => (item.english === current.english) && (item.french === current.french));
    if (!x) {
      return acc.concat([current]);
    } else {
      return acc;
    }
  }
    , []);


  //sort
  if (action.payload == "Asc") {
    uniques.sort((a, b) => (a.english > b.english) ? 1 : -1)
  } else if (action.payload == "Desc") {
    uniques.sort((a, b) => (b.english > a.english) ? 1 : -1)
  } else if (action.payload == "DescFr") {
    uniques.sort((a, b) => (b.french > a.french) ? 1 : -1)
  } else if (action.payload == "ascFr") {
    uniques.sort((a, b) => (a.french > b.french) ? 1 : -1)
  }

  switch (action.type) {
    case actionTypes.SORT:
      return {

        words: uniques
      }
    default:
      return state;
  }

};

export default reducer;


