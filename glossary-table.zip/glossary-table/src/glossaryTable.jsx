import React from "react";


import * as actionTypes from './actions';
import { connect } from "react-redux";

class GlossaryTable extends React.Component {

  render() {
    let { words } = this.props;
    return (
      <div className="glossaryTable">
        <div className="header text-center ">
          <h1 >Glossary</h1>
          <div className="btn-group" role="group" aria-label="Basic example">

          </div>
        </div>
        <section className='container'>

          <table className="table table-hover text-centered table-bordered table-sm table-striped">
            <thead className="thead-dark">
              <tr>
                <th >English&nbsp;&nbsp;
                   <i className="fa fa-arrow-up" onClick={() => this.props.onSort("Asc")} >&nbsp;&nbsp;</i>
                  <i className="fa fa-arrow-down" onClick={() => this.props.onSort("Desc")} ></i>

                </th>
                <th>French&nbsp;&nbsp;
                <i className="fa fa-arrow-up" onClick={() => this.props.onSort("AscFr")} >&nbsp;&nbsp;</i>
                <i className="fa fa-arrow-down" onClick={() => this.props.onSort("DescFr")} ></i>
           </th>
              </tr>
            </thead>
            <tbody>
              {words.map((w, i) =>
                <tr key={i}>
                  <td>{w.english}</td>
                  <td>{w.french}</td>
                </tr>
              )}
            </tbody>
          </table>
        </section>
      </div>
    );
  }
}

let mapStateToProps = (state) => {
  let { words } = state;
  return {
    words,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onSort: (value) => dispatch({ type: actionTypes.SORT, payload: value })
  }
};


export default connect(mapStateToProps, mapDispatchToProps)(GlossaryTable);